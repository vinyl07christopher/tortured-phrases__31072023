import react from 'react';

const Dashboard =()=>{
    return (

        <div>WelCome To Dashboard</div>

    )
}

export default Dashboard;